import React,{useEffect,useState} from 'react';
import {staticFile,useCurrentFrame,useVideoConfig,interpolate,Easing,delayRender,continueRender} from 'remotion';
import type {Caption} from '@remotion/captions';
const paper='#F6F0E6',yellow='#FFDD56';
export const Fonts:React.FC=()=>{
 const [handle]=useState(()=>delayRender('Loading Cyrillic fonts'));
 useEffect(()=>{Promise.all([
  new FontFace('EditorialSans',`url(${staticFile('fonts/Sans-Regular.ttf')})`,{weight:'400'}),
  new FontFace('EditorialSans',`url(${staticFile('fonts/Sans-Bold.ttf')})`,{weight:'700'}),
  new FontFace('EditorialSerif',`url(${staticFile('fonts/Serif-Italic.ttf')})`,{style:'italic'}),
 ].map(async font=>{await font.load();document.fonts.add(font);})).then(()=>continueRender(handle));},[handle]);return null;
};
export const Subtitles:React.FC<{items:Caption[]}>=({items})=>{
 const f=useCurrentFrame(),{fps}=useVideoConfig();
 const active=items.find(c=>f/fps*1000>=c.startMs&&f/fps*1000<c.endMs);
 if(!active)return null;
 return <div style={{position:'absolute',top:1480,left:84,width:882,height:100,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'EditorialSans',fontSize:62,lineHeight:1.2,fontWeight:700,color:yellow,whiteSpace:'nowrap',textShadow:'0 4px 6px #000, 0 1px 2px #000',letterSpacing:-1.3}}>{active.text}</div>;
};
export const Heading:React.FC<{eyebrow:string;first:string;second?:string;accent?:boolean}>=({eyebrow,first,second,accent=false})=>{
 const frame=useCurrentFrame();
 return <div style={{position:'absolute',top:140,left:80,width:920,textAlign:'center',opacity:interpolate(frame,[0,6],[0,1],{extrapolateRight:'clamp'}),translate:`0px ${interpolate(frame,[0,10],[12,0],{extrapolateRight:'clamp',easing:Easing.out(Easing.cubic)})}px`}}>
  <div style={{fontFamily:'EditorialSans',fontSize:23,letterSpacing:5,color:'#D6C9DB',marginBottom:22}}>{eyebrow}</div>
  <div style={{fontFamily:'EditorialSans',fontSize:82,lineHeight:1.13,letterSpacing:-2,fontWeight:700,color:paper}}>{first}</div>
  {second&&<div style={{fontFamily:'EditorialSerif',fontStyle:'italic',fontSize:96,lineHeight:1.12,color:accent?yellow:paper,marginTop:2}}>{second}</div>}
 </div>;
};
