import React from 'react';
import {AbsoluteFill, Composition, Sequence, staticFile, useCurrentFrame, useVideoConfig, interpolate} from 'remotion';
import {Audio, Video} from '@remotion/media';
import {Fonts, Heading, Subtitles} from './Shared';
import captions from './captions-second.json';
const FamilyQuestion:React.FC=()=>{
 const frame=useCurrentFrame();
 return <div style={{position:'absolute',top:147,left:84,width:882,textAlign:'center',opacity:interpolate(frame,[0,6],[0,1],{extrapolateRight:'clamp'})}}>
  <div style={{fontFamily:'EditorialSans',fontSize:23,letterSpacing:4,color:'#D6C9DB',marginBottom:23}}>ВАША АТМОСФЕРА ДОМА</div>
  <div style={{fontFamily:'EditorialSans',fontWeight:700,fontSize:76,color:'#F6F0E6',letterSpacing:-2,lineHeight:1.1,marginBottom:27}}>ЧТО ЧУВСТВУЮТ ДЕТИ?</div>
  <div style={{display:'flex',gap:20,fontFamily:'EditorialSans',fontSize:39,color:'#F6F0E6'}}>
   <div style={{width:431,padding:'16px 0',border:'1px solid #76677D',borderRadius:15,background:'#19151DE8'}}><span style={{color:'#FFDD56',fontWeight:700}}>А</span> Спокойствие</div>
   <div style={{width:431,padding:'16px 0',border:'1px solid #76677D',borderRadius:15,background:'#19151DE8'}}><span style={{color:'#FFDD56',fontWeight:700}}>Б</span> Напряжение</div>
  </div>
 </div>;
};
export const FamilyReel:React.FC=()=>{
 const frame=useCurrentFrame(),{fps,durationInFrames}=useVideoConfig(),t=frame/fps;
 const z=t<3.4?1.01:t<6.9?1.055:t<10.4?1:t<13.8?1.055:t<17.2?1:t<20.6?1.06:t<24?1:t<27.4?1.055:t<30.8?1.01:t<34.1?1.05:1;
 return <AbsoluteFill style={{backgroundColor:'#121016',overflow:'hidden'}}>
  <Fonts/>
  <Sequence name="Ради детей • единственный доступный дубль" durationInFrames={1110} premountFor={fps}>
   <Video name="Автор • без заключительной рекламы" src={staticFile('radi/source.mp4')} muted premountFor={fps} objectFit="cover" style={{width:1080,height:1920,scale:z,transformOrigin:'50% 43%',filter:'saturate(0.92) contrast(1.035) brightness(0.98)'}}/>
   <div style={{position:'absolute',inset:0,background:'linear-gradient(to bottom,rgba(18,16,22,.97) 0px,rgba(18,16,22,.88) 220px,rgba(18,16,22,.55) 340px,rgba(18,16,22,0) 505px)'}}/>
   <div style={{position:'absolute',left:0,right:0,top:1290,bottom:0,background:'linear-gradient(to bottom,rgba(18,16,22,0) 0px,rgba(18,16,22,.88) 95px,#121016 150px)'}}/>
   <Subtitles items={captions}/>
   <Sequence name="Хук • узнаваемая фраза" from={0} durationInFrames={Math.round(3.7*fps)} premountFor={fps}><Heading eyebrow="ОТНОШЕНИЯ · СЕМЬЯ И ДЕТИ" first="ВМЕСТЕ" second="ради детей?" accent/></Sequence>
   <Sequence name="Акцент • что дети чувствуют" from={Math.round(8.55*fps)} durationInFrames={Math.round(2.35*fps)} premountFor={fps}><Heading eyebrow="ДЕТИ ЗАМЕЧАЮТ АТМОСФЕРУ" first="ЗА ДЕЖУРНОЙ" second="улыбкой"/></Sequence>
   <Sequence name="Ключевые слова • сценарий" from={Math.round(25.6*fps)} durationInFrames={Math.round(3.9*fps)} premountFor={fps}><Heading eyebrow="ЧТО ПЕРЕДАЁТСЯ ДАЛЬШЕ" first="СЦЕНАРИЙ" second="по наследству"/></Sequence>
   <Sequence name="Один вопрос зрителю" from={Math.round(32.1*fps)} durationInFrames={durationInFrames-Math.round(32.1*fps)} premountFor={fps}><FamilyQuestion/></Sequence>
  </Sequence>
  <Audio name="Голос + оригинальный тихий ambient" src={staticFile('radi/master.wav')} premountFor={fps}/>
 </AbsoluteFill>;
};
export const SecondComposition:React.FC=()=> <Composition id="FamilyReel" component={FamilyReel} durationInFrames={1110} fps={30} width={1080} height={1920}/>;
