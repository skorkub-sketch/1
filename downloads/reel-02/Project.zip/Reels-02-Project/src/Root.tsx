import React from "react";
import {SecondComposition} from "./Second";
export const RemotionRoot:React.FC=()=> <SecondComposition/>;
