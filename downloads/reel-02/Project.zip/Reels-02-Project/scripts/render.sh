#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p out
browser_args=()
if command -v chromium >/dev/null 2>&1; then browser_args+=(--browser-executable="$(command -v chromium)"); fi
npx remotion render src/index.ts FamilyReel out/Reels-02-Family-render.mp4 --codec=h264 --crf=18 --pixel-format=yuv420p --audio-codec=aac --audio-bitrate=192k --concurrency=3 "${browser_args[@]}"
ffmpeg -v error -i out/Reels-02-Family-render.mp4 -vf 'scale=in_range=auto:out_range=tv:out_color_matrix=bt709,format=yuv420p' -c:v libx264 -crf 18 -preset medium -threads 3 -pix_fmt yuv420p -color_range tv -colorspace bt709 -color_primaries bt709 -color_trc bt709 -c:a copy -movflags +faststart -y out/Reels-02-Family.mp4
