#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ffmpeg -v error -i public/radi/source.mp4 -t 37.0 -vn -af 'highpass=f=75,lowpass=f=14000,loudnorm=I=-16:TP=-1.8:LRA=9,alimiter=limit=0.82:level=false' -ar 48000 -ac 2 -y public/radi/voice.wav
ffmpeg -v error -i public/radi/voice.wav -i public/radi/music.wav -filter_complex '[0:a][1:a]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.88:level=false,afade=t=out:st=36.75:d=0.25[a]' -map '[a]' -c:a pcm_s16le -y public/radi/master.wav
