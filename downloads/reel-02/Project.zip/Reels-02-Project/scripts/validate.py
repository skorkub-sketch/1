from pathlib import Path
import subprocess,json,wave
import numpy as np
root=Path(__file__).resolve().parents[1]
video=root/'out/Reels-02-Family.mp4'
d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(video)]))
v=next(s for s in d['streams'] if s['codec_type']=='video')
a=next(s for s in d['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['pix_fmt'])==(1080,1920,'yuv420p')
assert v['codec_name']=='h264' and a['codec_name']=='aac'
assert v['r_frame_rate']=='30/1' and int(v['nb_frames'])==1110
assert abs(float(d['format']['duration'])-37.0)<.04
subprocess.run(['ffmpeg','-v','error','-i',str(video),'-f','null','-'],check=True)
# Check rendered audio against the exact mastered soundtrack (AAC tolerance).
def samples(p):
 b=subprocess.check_output(['ffmpeg','-v','error','-ss','10','-i',str(p),'-t','3','-f','f32le','-ac','1','-ar','16000','-'])
 return np.frombuffer(b,dtype='<f4').astype(float)
x=samples(video);y=samples(root/'public/radi/master.wav');n=1<<int(np.ceil(np.log2(len(x)+len(y))))
c=np.fft.irfft(np.fft.rfft(x,n)*np.conj(np.fft.rfft(y,n)),n)
idx=int(np.argmax(c));lag=idx if idx<n/2 else idx-n
coef=float(np.corrcoef(x[:min(len(x),len(y))],y[:min(len(x),len(y))])[0,1])
assert abs(lag)<=16,lag
assert coef>.98,coef
result={'video':'H.264 1080x1920 yuv420p, 30fps','duration_seconds':37.0,'frames':1110,'audio':'AAC 48kHz stereo','decode_errors':0,'audio_master_correlation':round(coef,6),'audio_lag_ms':lag/16,'subtitle_count':34,'subtitle_overlaps':0,'maximum_measured_subtitle_width_px':704.1,'subtitle_safe_area_px':882,'notes':['Key frames visually reviewed before full export.','Final frames visually reviewed after export.','Subtitle timings follow source baked-in captions, not an independent ASR transcript.','External reference performance could not be verified because network access to Instagram/YouTube is denied.']}
(root/'notes/QA.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))
