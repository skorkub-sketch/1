#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ ! -f assets/selected.mp4 ]]; then bash src/prepare.sh; fi
ffmpeg -v error -i assets/selected.mp4 -vn -af 'highpass=f=75,lowpass=f=14000,loudnorm=I=-16:TP=-1.8:LRA=9,alimiter=limit=0.82:level=false,apad=whole_dur=38.2' -t 38.2 -ar 48000 -ac 2 -y assets/voice.wav
python src/pad_voice.py
ffmpeg -v error -i assets/voice.wav -i assets/music.wav -filter_complex '[0:a][1:a]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.88:level=false,afade=t=out:st=38:d=0.2[a]' -map '[a]' -c:a pcm_s16le -y assets/master.wav
