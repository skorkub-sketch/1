from pathlib import Path
import json,numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
rows=[(0.28, 1.25, 'Если вы думаете,'), (1.25, 1.95, 'что признак'), (1.95, 2.95, 'умирающего брака —'), (2.95, 3.95, 'это скандалы'), (3.95, 4.95, 'и битая посуда…'), (5.28, 5.95, 'На самом деле'), (5.95, 7.25, 'брак чаще всего'), (7.25, 8.35, 'умирает в тишине.'), (9.3, 9.65, 'Когда'), (9.65, 10.68, 'нет скандалов,'), (10.95, 12.3, 'претензий тоже нет.'), (12.6, 13.1, 'Тишина.'), (13.3, 14.62, 'Всё общение'), (14.62, 15.35, 'свелось к разговору:'), (15.6, 16.65, '«Ребёнка забрал?»'), (16.95, 17.3, '«Поел?»'), (17.3, 19.8, '«На Ozon / WB сходил?»'), (20.6, 21.65, 'Скандал — это признак'), (21.65, 22.3, 'того,'), (22.3, 22.95, 'что человеку'), (22.95, 24, 'ещё не всё равно.'), (24.3, 25.3, 'Он пытается ещё'), (25.3, 26, 'достучаться,'), (26, 26.7, 'как может.'), (27, 28.55, 'А вот равнодушие —'), (28.55, 30.1, 'это симптом «комы».'), (30.6, 31.25, 'И здесь есть'), (31.25, 32.65, 'только два варианта:'), (33.25, 34.9, 'либо реанимация,'), (35.25, 36.9, 'либо…'), (36.9, 38.05, 'честный разговор.')]
c=[dict(text=s.strip(),startMs=round(a*1000),endMs=round(b*1000),timestampMs=None,confidence=None) for a,b,s in rows]
(ROOT/'src/captions.json').write_text(json.dumps(c,ensure_ascii=False,indent=2))
f=ImageFont.truetype(str(ROOT/'assets/fonts/Sans-Bold.ttf'),62)
assert max(f.getlength(q['text'])-1.3*(len(q['text'])-1) for q in c)<882
assert all(a['endMs']<=b['startMs'] for a,b in zip(c,c[1:]))
y=np.arange(1920)
top=np.interp(y,[0,220,340,505],[.97,.88,.55,0]);bottom=np.interp(y,[1290,1385,1440],[0,.88,1]);alpha=1-(1-top)*(1-bottom)
a=np.zeros((1920,1080,4),dtype=np.uint8);a[:,:,:3]=[18,16,22];a[:,:,3]=(alpha[:,None]*255).astype('uint8');Image.fromarray(a).save(ROOT/'assets/background.png')
im=Image.new('RGBA',(1080,1920));d=ImageDraw.Draw(im)
for x in [84,535]:d.rounded_rectangle((x,302,x+431,385),radius=15,fill=(25,21,29,232),outline=(118,103,125,255),width=1)
im.save(ROOT/'assets/poll-boxes.png')
header='''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.709

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Caption,Noto Sans,84,&H0056DDFF,&H0056DDFF,&H00000000,&H00000000,-1,0,0,0,100,100,-1.3,0,1,0,4,8,84,114,1480,1
Style: Head,Noto Sans,112,&H00E6F0F6,&H00E6F0F6,&H00000000,&H00000000,-1,0,0,0,100,100,-2,0,1,0,0,8,80,80,190,1
Style: Accent,Noto Serif,130,&H00E6F0F6,&H00E6F0F6,&H00000000,&H00000000,0,-1,0,0,100,100,0,0,1,0,0,8,80,80,284,1
Style: Eyebrow,Noto Sans,31,&H00DBC9D6,&H00DBC9D6,&H00000000,&H00000000,0,0,0,0,100,100,4,0,1,0,0,8,80,80,140,1
Style: Poll,Noto Sans,53,&H00E6F0F6,&H00E6F0F6,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,5,80,80,140,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
def ts(t):
 cs=round(t*100);return f'{cs//360000}:{cs//6000%60:02}:{cs//100%60:02}.{cs%100:02}'
lines=[]
def event(a,b,style,text,tags='',layer=1):lines.append(f'Dialogue: {layer},{ts(a)},{ts(b)},{style},,0,0,0,,{{{tags}}}{text}')
for a,b,s in rows:event(a,b,'Caption',s.strip(),'\\an8\\pos(525,1480)',2)
def heading(a,b,eye,first,second,yellow=False):
 for st,txt,yy in [('Eyebrow',eye,140),('Head',first,190),('Accent',second,284)]:
  tags=f'\\an8\\move(540,{yy+12},540,{yy},0,333)\\fad(200,0)'
  if yellow and st=='Accent':tags+='\\c&H56DDFF&'
  event(a,b,st,txt,tags)
heading(0,3.5,'ОТНОШЕНИЯ · ЧУВСТВА И ТИШИНА','ДОМА ТИХО.','Всё хорошо?',True)
heading(13.3,16.25,'КОГДА ОСТАЛИСЬ ТОЛЬКО ДЕЛА','ТОЛЬКО','бытовые вопросы')
heading(27,30.2,'КОГДА УХОДИТ ЭМОЦИОНАЛЬНЫЙ КОНТАКТ','РАВНОДУШИЕ','сигнал тревоги')
event(33.3,38.2,'Eyebrow','КОГДА ВЫ ВДВОЁМ','\\an8\\pos(540,147)\\fad(200,0)')
event(33.3,38.2,'Head','О ЧЁМ ГОВОРИТЕ?','\\an8\\pos(540,201)\\fs104\\fad(200,0)')
for x,letter,text in [(299.5,'А','О делах'),(750.5,'Б','О чувствах')]:
 event(33.3,38.2,'Poll',f'{{\\c&H56DDFF&\\b1}}{letter}{{\\c&HE6F0F6&\\b0}} {text}',f'\\an5\\pos({x},343.5)\\fad(200,0)')
(ROOT/'src/design.ass').write_text(header+'\n'.join(lines)+'\n')
def srt_ts(ms):return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(ROOT/'out/Subtitles.srt').write_text('\n\n'.join(f'{i+1}\n{srt_ts(q["startMs"])} --> {srt_ts(q["endMs"])}\n{q["text"]}' for i,q in enumerate(c))+'\n')
print('Generated',len(c),'captions and reusable style assets.')
