#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ffmpeg -v error -i assets/source.mp4 -filter_complex '[0:v]split=2[x][y];[x]trim=end=5.1,setpts=PTS-STARTPTS[v0];[y]trim=start=6.1,setpts=PTS-STARTPTS[v1];[v0][v1]concat=n=2:v=1:a=0[v];[0:a]asplit=2[a][b];[a]atrim=end=5.1,asetpts=PTS-STARTPTS[a0];[b]atrim=start=6.1,asetpts=PTS-STARTPTS[a1];[a0][a1]concat=n=2:v=0:a=1[aout]' -map '[v]' -map '[aout]' -c:v libx264 -crf 14 -preset fast -threads 3 -c:a aac -b:a 256k -y assets/selected.mp4
