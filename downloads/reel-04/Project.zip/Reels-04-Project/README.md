# Четвёртый Reels — «Скандалы»

38.2 секунды · 1080×1920 · 30 fps · без бегунка.

Нужны FFmpeg с libass, Python 3, NumPy и Pillow:

```bash
python src/design.py
bash src/render.sh --preview
bash src/render.sh
```

Предпросмотр: `out/key-*.png`. Готовый файл: `out/Reels-04.mp4`.

`assets/source.mp4` — оригинал. `src/prepare.sh` вырезает одну секунду паузы и создаёт `assets/selected.mp4`; этот промежуточный файл автоматически создаётся при запуске, если отсутствует. `src/design.py` содержит монтажные тайминги и текст. `src/captions.json` и `src/design.ass` — сохранённые субтитры и оформление. Для правок текста меняйте `rows` в `src/design.py` и запускайте генерацию повторно. Музыка оригинальная, генератор в `src/music.py`; раздельные аудиодорожки сохранены в `assets/`.

В `notes/` — карточка стиля, монтажное решение и проверка экспорта. Шрифты Noto, лицензия SIL OFL в `notes/FONT-LICENSE.txt`. Исходник 720×1280 масштабирован до 1080×1920. Доступен один дубль этого текста.
