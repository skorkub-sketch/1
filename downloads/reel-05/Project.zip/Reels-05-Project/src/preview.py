from pathlib import Path
import re,subprocess
root=Path(__file__).resolve().parents[1]
s=(root/'src/render.sh').read_text();f=re.search(r'filter="([^\n]+)"',s).group(1)
f=f.replace('[0:v]',"[0:v]select='eq(n,30)+eq(n,375)+eq(n,567)+eq(n,1077)',")
f=re.sub(r"zoompan=z='[^']+'","zoompan=z='if(eq(on,0),1.01,if(eq(on,1),1.055,if(eq(on,2),1.06,1.01)))'",f)
f=f.replace(',tpad=stop_mode=clone:stop_duration=0.066667','').replace('setpts=PTS-STARTPTS[base]',"setpts='if(eq(N,0),30,if(eq(N,1),375,if(eq(N,2),567,1077)))/(30*TB)'[base]")
subprocess.run(['ffmpeg','-hide_banner','-loglevel','warning','-i','assets/source.mp4','-loop','1','-framerate','30','-i','assets/background.png','-loop','1','-framerate','30','-i','assets/poll-boxes.png','-filter_complex_threads','2','-filter_complex',f,'-map','[v]','-an','-fps_mode','vfr','-frames:v','4','-y','out/key-%02d.png'],cwd=root,check=True)
