from pathlib import Path
import wave
p=Path(__file__).resolve().parents[1]/'assets/voice.wav'
with wave.open(str(p),'rb') as w:
 params=w.getparams();n=round(37.4*w.getframerate());data=w.readframes(w.getnframes());frame_bytes=w.getnchannels()*w.getsampwidth()
if len(data)!=n*frame_bytes:
 data=data[:n*frame_bytes]+bytes(max(0,n*frame_bytes-len(data)))
 q=p.with_name('voice-padded.wav')
 with wave.open(str(q),'wb') as w:w.setparams(params);w.writeframes(data)
 q.replace(p)
