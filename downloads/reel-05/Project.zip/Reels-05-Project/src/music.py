import numpy as np,wave
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sr=48000;dur=37.4;t=np.arange(round(sr*dur))/sr
rng=np.random.default_rng(10616);out=np.zeros((len(t),2))
# Original sparse ambient chords; synthesized here, no sampled recordings.
chords=[[57,60,64,71],[53,57,60,67],[48,55,59,64],[55,59,62,69]]
for bar in range(10):
 start=bar*4.; local=t-start
 env=np.where(local>=0,(1-np.exp(-np.maximum(local,0)/.45))*np.exp(-np.maximum(local,0)/2.7),0)
 for n,m in enumerate(chords[bar%4]):
  f=440*2**((m-69)/12)
  for c in range(2):
   sig=np.sin(2*np.pi*f*(1+(c*2-1)*.0005)*local + n*.19)
   sig+=.18*np.sin(2*np.pi*f*2*local)*np.exp(-np.maximum(local,0)/1.4)
   out[:,c]+=sig*env*.022
fade=np.minimum(t/1.2,1)*np.minimum(np.maximum((dur-t)/1.4,0),1)
out*=fade[:,None]
out*=.018/np.sqrt(np.mean(out**2))
with wave.open(str(root/'assets/music.wav'),'wb') as w:
 w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((np.clip(out,-1,1)*32767).astype('<i2').tobytes())
