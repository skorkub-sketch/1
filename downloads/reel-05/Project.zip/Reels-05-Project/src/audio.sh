#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ffmpeg -v error -i assets/source.mp4 -vn -af 'highpass=f=75,lowpass=f=14000,loudnorm=I=-16:TP=-1.8:LRA=9,alimiter=limit=0.82:level=false,apad=whole_dur=37.4' -t 37.4 -ar 48000 -ac 2 -y assets/voice.wav
python src/pad_voice.py
ffmpeg -v error -i assets/voice.wav -i assets/music.wav -filter_complex '[0:a][1:a]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.88:level=false,afade=t=out:st=37.35:d=0.05[a]' -map '[a]' -c:a pcm_s16le -y assets/master.wav
