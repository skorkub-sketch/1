from pathlib import Path
import json,numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
rows=[(0.6, 1.3, 'Есть простой'), (1.3, 2.3, 'тест на отношения,'), (2.3, 3, 'о котором'), (3, 3.95, 'редко говорят.'), (3.95, 5, 'Что вы чувствуете,'), (5.3, 5.95, 'когда'), (5.95, 7.3, 'ключ поворачивается'), (7.3, 7.75, 'в замке,'), (7.95, 8.6, 'а муж или жена'), (8.6, 9.7, 'заходит домой?'), (10.3, 11.3, 'Если внутри'), (11.3, 11.65, 'всё'), (11.65, 12.6, 'сжимается'), (12.6, 13.95, 'и наваливается'), (13.95, 14.7, 'тяжесть,'), (14.95, 16.25, 'а настоящее чувство'), (16.25, 16.95, 'облегчения'), (16.95, 17.95, 'вы испытываете'), (17.95, 19, 'только тогда,'), (19.3, 20.4, 'когда партнёр'), (20.95, 21.3, 'уезжает'), (21.3, 22.25, 'в командировку'), (22.25, 23.35, 'или к друзьям,'), (23.6, 24.25, 'ваше тело уже'), (24.25, 25.35, 'приняло решение.'), (25.6, 27.6, 'Психика воспринимает'), (27.6, 28.95, 'человека рядом'), (28.95, 30, 'не как опору,'), (30.25, 31.6, 'а как источник'), (31.6, 32.95, 'хронической угрозы.'), (33.6, 34.6, 'Из этой точки'), (34.6, 35.3, 'чинить брак'), (35.3, 35.95, 'уговорами'), (35.95, 37.3, 'уже не получится.')]
c=[dict(text=s.strip(),startMs=round(a*1000),endMs=round(b*1000),timestampMs=None,confidence=None) for a,b,s in rows]
(ROOT/'src/captions.json').write_text(json.dumps(c,ensure_ascii=False,indent=2))
f=ImageFont.truetype(str(ROOT/'assets/fonts/Sans-Bold.ttf'),62)
assert max(f.getlength(q['text'])-1.3*(len(q['text'])-1) for q in c)<882
assert all(a['endMs']<=b['startMs'] for a,b in zip(c,c[1:]))
y=np.arange(1920)
top=np.interp(y,[0,220,340,505],[.97,.88,.55,0]);bottom=np.interp(y,[1290,1385,1440],[0,.88,1]);alpha=1-(1-top)*(1-bottom)
a=np.zeros((1920,1080,4),dtype=np.uint8);a[:,:,:3]=[18,16,22];a[:,:,3]=(alpha[:,None]*255).astype('uint8');Image.fromarray(a).save(ROOT/'assets/background.png')
im=Image.new('RGBA',(1080,1920));d=ImageDraw.Draw(im)
for x in [84,535]:d.rounded_rectangle((x,302,x+431,385),radius=15,fill=(25,21,29,232),outline=(118,103,125,255),width=1)
im.save(ROOT/'assets/poll-boxes.png')
header='''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.709

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Caption,Noto Sans,84,&H0056DDFF,&H0056DDFF,&H00000000,&H00000000,-1,0,0,0,100,100,-1.3,0,1,0,4,8,84,114,1480,1
Style: Head,Noto Sans,112,&H00E6F0F6,&H00E6F0F6,&H00000000,&H00000000,-1,0,0,0,100,100,-2,0,1,0,0,8,80,80,190,1
Style: Accent,Noto Serif,130,&H00E6F0F6,&H00E6F0F6,&H00000000,&H00000000,0,-1,0,0,100,100,0,0,1,0,0,8,80,80,284,1
Style: Eyebrow,Noto Sans,31,&H00DBC9D6,&H00DBC9D6,&H00000000,&H00000000,0,0,0,0,100,100,4,0,1,0,0,8,80,80,140,1
Style: Poll,Noto Sans,53,&H00E6F0F6,&H00E6F0F6,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,5,80,80,140,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
def ts(t):
 cs=round(t*100);return f'{cs//360000}:{cs//6000%60:02}:{cs//100%60:02}.{cs%100:02}'
lines=[]
def event(a,b,style,text,tags='',layer=1):lines.append(f'Dialogue: {layer},{ts(a)},{ts(b)},{style},,0,0,0,,{{{tags}}}{text}')
for a,b,s in rows:event(a,b,'Caption',s.strip(),'\\an8\\pos(525,1480)',2)
def heading(a,b,eye,first,second,yellow=False):
 for st,txt,yy in [('Eyebrow',eye,140),('Head',first,190),('Accent',second,284)]:
  tags=f'\\an8\\move(540,{yy+12},540,{yy},0,333)\\fad(200,0)'
  if yellow and st=='Accent':tags+='\\c&H56DDFF&'
  event(a,b,st,txt,tags)
heading(0,3.5,'ОТНОШЕНИЯ · РЕАКЦИЯ ТЕЛА','КЛЮЧ В ЗАМКЕ.','Что внутри?',True)
heading(11.65,14.7,'ЧТО ПРОИСХОДИТ В МОМЕНТ ВСТРЕЧИ','СЖИМАЕТСЯ','внутри')
heading(17,20.25,'КОГДА ПОЯВЛЯЕТСЯ ВЫДОХ','ОБЛЕГЧЕНИЕ','на расстоянии')
event(33.5,37.4,'Eyebrow','РЯДОМ С ПАРТНЁРОМ','\\an8\\pos(540,147)\\fad(200,0)')
event(33.5,37.4,'Head','ЧТО ВНУТРИ?','\\an8\\pos(540,201)\\fs104\\fad(200,0)')
for x,letter,text in [(299.5,'А','Спокойствие'),(750.5,'Б','Напряжение')]:
 event(33.5,37.4,'Poll',f'{{\\c&H56DDFF&\\b1}}{letter}{{\\c&HE6F0F6&\\b0}} {text}',f'\\an5\\pos({x},343.5)\\fad(200,0)')
(ROOT/'src/design.ass').write_text(header+'\n'.join(lines)+'\n')
def srt_ts(ms):return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(ROOT/'out/Subtitles.srt').write_text('\n\n'.join(f'{i+1}\n{srt_ts(q["startMs"])} --> {srt_ts(q["endMs"])}\n{q["text"]}' for i,q in enumerate(c))+'\n')
print('Generated',len(c),'captions and reusable style assets.')
