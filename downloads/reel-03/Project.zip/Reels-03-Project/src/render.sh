#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p out .cache
export XDG_CACHE_HOME="$PWD/.cache"
# Same composition, rendered directly with FFmpeg to avoid repeatedly decoding video in a browser.
filter="[0:v]tpad=stop_mode=clone:stop_duration=0.3,zoompan=z='if(lt(on,102),1.01,if(lt(on,204),1.055,if(lt(on,306),1,if(lt(on,408),1.055,if(lt(on,510),1,if(lt(on,612),1.06,if(lt(on,714),1.01,if(lt(on,816),1.055,1))))))))':x='(iw-iw/zoom)/2':y='(ih-ih/zoom)*0.43':d=1:s=1080x1920:fps=30,eq=contrast=1.035:brightness=-0.01:saturation=0.92,setpts=PTS-STARTPTS[base];[base][1:v]overlay=0:0:format=auto:shortest=1[bg];[bg][2:v]overlay=0:0:format=auto:shortest=1:enable='between(t,25.3,30)'[pan];[pan]ass=src/design.ass:fontsdir=assets/fonts,format=yuv420p[v]"
if [[ "${1:-}" == "--preview" ]]; then
 python src/preview.py
 exit 0
fi
ffmpeg -hide_banner -loglevel warning -i assets/source.mp4 -loop 1 -framerate 30 -i assets/background.png -loop 1 -framerate 30 -i assets/poll-boxes.png -filter_complex_threads 2 -filter_complex "$filter" -map '[v]' -frames:v 900 -t 30 -an -c:v libx264 -crf 18 -preset medium -threads 3 -color_range tv -colorspace bt709 -color_primaries bt709 -color_trc bt709 -y out/video-only.mp4
ffmpeg -hide_banner -loglevel warning -i out/video-only.mp4 -i assets/master.wav -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -t 30 -movflags +faststart -y out/Reels-03.partial.mp4
mv out/Reels-03.partial.mp4 out/Reels-03.mp4
