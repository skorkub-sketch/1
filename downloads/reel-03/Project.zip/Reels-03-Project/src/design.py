from pathlib import Path
import json,numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
rows=[(.28,.96,'Когда женщина'),(.96,1.64,'в сотый раз'),(1.64,2.6,'говорит мужчине:'),(2.6,3.3,'«Нам надо поговорить'),(3.3,4.0,'об отношениях» —'),(4.0,4.97,'что он слышит?'),(5.3,6.2,'Он слышит:'),(6.2,7.24,'«Сейчас тебя'),(7.24,8.35,'будут судить'),(8.93,10.3,'и делать виноватым».'),(10.6,11.3,'Мужчина'),(11.3,11.95,'моментально'),(11.95,12.95,'закрывается'),(12.95,14.02,'в глухую оборону.'),(14.3,15.95,'А женщина решает:'),(15.95,17.02,'«Ему плевать». '),(17.6,18.62,'А ему не плевать.'),(18.62,19.28,'Он просто'),(19.28,19.95,'защищается'),(19.95,21.35,'от публичной казни.'),(21.6,22.28,'Отношения'),(22.28,23.92,'не чинятся допросами.'),(23.92,24.6,'Они чинятся'),(24.6,25.28,'действиями'),(25.28,26.25,'и восстановлением'),(26.25,27.0,'безопасности.'),(27.0,27.62,'Как выходить'),(27.62,28.95,'из этих ситуаций —'),(28.95,29.85,'у меня в канале.')]
c=[dict(text=s.strip(),startMs=round(a*1000),endMs=round(b*1000),timestampMs=None,confidence=None) for a,b,s in rows]
(ROOT/'src/captions.json').write_text(json.dumps(c,ensure_ascii=False,indent=2))
f=ImageFont.truetype(str(ROOT/'assets/fonts/Sans-Bold.ttf'),62)
assert max(f.getlength(q['text'])-1.3*(len(q['text'])-1) for q in c)<882
assert all(a['endMs']<=b['startMs'] for a,b in zip(c,c[1:]))
y=np.arange(1920)
top=np.interp(y,[0,220,340,505],[.97,.88,.55,0]);bottom=np.interp(y,[1290,1385,1440],[0,.88,1]);alpha=1-(1-top)*(1-bottom)
a=np.zeros((1920,1080,4),dtype=np.uint8);a[:,:,:3]=[18,16,22];a[:,:,3]=(alpha[:,None]*255).astype('uint8');Image.fromarray(a).save(ROOT/'assets/background.png')
im=Image.new('RGBA',(1080,1920));d=ImageDraw.Draw(im)
for x in [84,535]:d.rounded_rectangle((x,302,x+431,385),radius=15,fill=(25,21,29,232),outline=(118,103,125,255),width=1)
im.save(ROOT/'assets/poll-boxes.png')
header='''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.709

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Caption,Noto Sans,84,&H0056DDFF,&H0056DDFF,&H00000000,&H00000000,-1,0,0,0,100,100,-1.3,0,1,0,4,8,84,114,1480,1
Style: Head,Noto Sans,112,&H00E6F0F6,&H00E6F0F6,&H00000000,&H00000000,-1,0,0,0,100,100,-2,0,1,0,0,8,80,80,190,1
Style: Accent,Noto Serif,130,&H00E6F0F6,&H00E6F0F6,&H00000000,&H00000000,0,-1,0,0,100,100,0,0,1,0,0,8,80,80,284,1
Style: Eyebrow,Noto Sans,31,&H00DBC9D6,&H00DBC9D6,&H00000000,&H00000000,0,0,0,0,100,100,4,0,1,0,0,8,80,80,140,1
Style: Poll,Noto Sans,53,&H00E6F0F6,&H00E6F0F6,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,5,80,80,140,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
def ts(t):
 cs=round(t*100);return f'{cs//360000}:{cs//6000%60:02}:{cs//100%60:02}.{cs%100:02}'
lines=[]
def event(a,b,style,text,tags='',layer=1):lines.append(f'Dialogue: {layer},{ts(a)},{ts(b)},{style},,0,0,0,,{{{tags}}}{text}')
for a,b,s in rows:event(a,b,'Caption',s.strip(),'\\an8\\pos(525,1480)',2)
def heading(a,b,eye,first,second,yellow=False):
 for st,txt,yy in [('Eyebrow',eye,140),('Head',first,190),('Accent',second,284)]:
  tags=f'\\an8\\move(540,{yy+12},540,{yy},0,333)\\fad(200,0)'
  if yellow and st=='Accent':tags+='\\c&H56DDFF&'
  event(a,b,st,txt,tags)
heading(0,3.4,'ОТНОШЕНИЯ · ТРУДНЫЙ РАЗГОВОР','РАЗГОВОР','или допрос?',True)
heading(10.65,13.95,'КОГДА РАЗГОВОР КАЖЕТСЯ СУДОМ','ГЛУХАЯ','оборона')
heading(21.6,24.7,'ТОЧКА ОПОРЫ ДЛЯ ДИАЛОГА','НЕ ДОПРОС','а безопасность')
event(25.3,30,'Eyebrow','КАК ВЕРНУТЬСЯ К ДИАЛОГУ','\\an8\\pos(540,147)\\fad(200,0)')
event(25.3,30,'Head','ЧТО ПОМОГАЕТ?','\\an8\\pos(540,201)\\fs104\\fad(200,0)')
for x,letter,text in [(299.5,'А','Спокойный тон'),(750.5,'Б','Конкретный шаг')]:
 event(25.3,30,'Poll',f'{{\\c&H56DDFF&\\b1}}{letter}{{\\c&HE6F0F6&\\b0}} {text}',f'\\an5\\pos({x},343.5)\\fad(200,0)')
(ROOT/'src/design.ass').write_text(header+'\n'.join(lines)+'\n')
def srt_ts(ms):return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(ROOT/'out/Subtitles.srt').write_text('\n\n'.join(f'{i+1}\n{srt_ts(q["startMs"])} --> {srt_ts(q["endMs"])}\n{q["text"]}' for i,q in enumerate(c))+'\n')
print('Generated',len(c),'captions and reusable style assets.')
